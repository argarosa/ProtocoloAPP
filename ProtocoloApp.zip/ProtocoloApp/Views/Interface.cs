﻿namespace ProtocoloApp.Views
{
    public interface Interface
    {
    }
}
