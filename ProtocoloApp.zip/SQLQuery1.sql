CREATE DATABASE ProtocoloDB;
USE ProtocoloDB;
CREATE TABLE Cliente (
    IdCliente INT PRIMARY KEY IDENTITY(1,1),
    Nome VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Telefone VARCHAR(15),
    Endereco VARCHAR(255)
);
CREATE TABLE StatusProtocolo (
    IdStatus INT PRIMARY KEY IDENTITY(1,1),
    NomeStatus VARCHAR(50) NOT NULL
);
CREATE TABLE Protocolo (
    IdProtocolo INT PRIMARY KEY IDENTITY(1,1),
    Titulo VARCHAR(100) NOT NULL,
    Descricao TEXT,
    DataAbertura DATETIME DEFAULT GETDATE(),
    DataFechamento DATETIME,
    ClienteId INT,
    ProtocoloStatusId INT,
    FOREIGN KEY (ClienteId) REFERENCES Cliente(IdCliente),
    FOREIGN KEY (ProtocoloStatusId) REFERENCES StatusProtocolo(IdStatus)
);
CREATE TABLE ProtocoloFollow (
    IdFollow INT PRIMARY KEY IDENTITY(1,1),
    ProtocoloId INT,
    DataAcao DATETIME DEFAULT GETDATE(),
    DescricaoAcao TEXT,
    FOREIGN KEY (ProtocoloId) REFERENCES Protocolo(IdProtocolo)
);